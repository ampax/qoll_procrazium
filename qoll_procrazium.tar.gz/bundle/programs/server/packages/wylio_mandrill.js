(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var Email = Package.email.Email;
var HTTP = Package.http.HTTP;

(function () {

///////////////////////////////////////////////////////////////////////////////////
//                                                                               //
// packages/wylio:mandrill/mandrill.js                                           //
//                                                                               //
///////////////////////////////////////////////////////////////////////////////////
                                                                                 //
Meteor.Mandrill = {                                                              // 1
    options: {},                                                                 // 2
    config: function (options) {                                                 // 3
        this.options.username = options["username"];                             // 4
        this.options.key = options["key"];                                       // 5
        this.options.host = "smtp.mandrillapp.com";                              // 6
        this.options.port = "587";                                               // 7
        // setn the environment SMTP server                                      // 8
        process.env.MAIL_URL = "smtp://" + this.options.username + ":" + this.options.key + "@" + this.options.host + ":" + this.options.port + "/";
    },                                                                           // 10
    send: function (options) {                                                   // 11
        Email.send(options);                                                     // 12
    },                                                                           // 13
    sendTemplate: function (options) {                                           // 14
        var url = "https://mandrillapp.com/api/1.0/messages/send-template.json", // 15
            result;                                                              // 16
                                                                                 // 17
        options = {                                                              // 18
            "data": {                                                            // 19
                "key": options.key || this.options.key,                          // 20
                "template_name": options.template_name,                          // 21
                "template_content": options.template_content,                    // 22
                "message": options.message,                                      // 23
                "headers": [{                                                    // 24
                    "Content-Type": "application/json"                           // 25
                }]                                                               // 26
            }                                                                    // 27
        };                                                                       // 28
                                                                                 // 29
        try {                                                                    // 30
            return HTTP.post(url, options);                                      // 31
        } catch (err) {                                                          // 32
            console.error(err);                                                  // 33
        }                                                                        // 34
    }                                                                            // 35
};                                                                               // 36
                                                                                 // 37
///////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['wylio:mandrill'] = {};

})();

//# sourceMappingURL=wylio_mandrill.js.map
