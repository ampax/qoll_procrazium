(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;

/* Package-scope variables */
var GoogleContacts, chunk_buffer, params;

(function () {

/////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                     //
// packages/long:google-contacts/index.js                                                              //
//                                                                                                     //
/////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                       //
/**                                                                                                    // 1
 * @todo: recursively send requests until all contacts are fetched                                     // 2
 *                                                                                                     // 3
 * @see https://developers.google.com/google-apps/contacts/v3/reference#ContactsFeed                   // 4
 *                                                                                                     // 5
 * To API test requests:                                                                               // 6
 *                                                                                                     // 7
 * @see https://developers.google.com/oauthplayground/                                                 // 8
 *                                                                                                     // 9
 * To format JSON nicely:                                                                              // 10
 *                                                                                                     // 11
 * @see http://jsonviewer.stack.hu/                                                                    // 12
 *                                                                                                     // 13
 * Note: The Contacts API has a hard limit to the number of results it can return at a                 // 14
 * time even if you explicitly request all possible results. If the requested feed has                 // 15
 * more fields than can be returned in a single response, the API truncates the feed and adds          // 16
 * a "Next" link that allows you to request the rest of the response.                                  // 17
 */                                                                                                    // 18
var EventEmitter = Npm.require('events').EventEmitter,                                                 // 19
  _ = Npm.require('underscore'),                                                                       // 20
  qs = Npm.require('querystring'),                                                                     // 21
  util = Npm.require('util'),                                                                          // 22
  url = Npm.require('url'),                                                                            // 23
  https = Npm.require('https'),                                                                        // 24
  querystring = Npm.require('querystring');                                                            // 25
                                                                                                       // 26
GoogleContacts = function (opts) {                                                                     // 27
  if (typeof opts === 'string') {                                                                      // 28
    opts = { token: opts };                                                                            // 29
  }                                                                                                    // 30
  if (!opts) {                                                                                         // 31
    opts = {};                                                                                         // 32
  }                                                                                                    // 33
                                                                                                       // 34
  this.contacts = [];                                                                                  // 35
  this.consumerKey = opts.consumerKey ? opts.consumerKey : null;                                       // 36
  this.consumerSecret = opts.consumerSecret ? opts.consumerSecret : null;                              // 37
  this.token = opts.token ? opts.token : null;                                                         // 38
  this.refreshToken = opts.refreshToken ? opts.refreshToken : null;                                    // 39
};                                                                                                     // 40
                                                                                                       // 41
GoogleContacts.prototype = {};                                                                         // 42
                                                                                                       // 43
util.inherits(GoogleContacts, EventEmitter);                                                           // 44
                                                                                                       // 45
                                                                                                       // 46
GoogleContacts.prototype._get = function (params, cb) {                                                // 47
  var self = this;                                                                                     // 48
                                                                                                       // 49
  if (typeof params === 'function') {                                                                  // 50
    cb = params;                                                                                       // 51
    params = {};                                                                                       // 52
  }                                                                                                    // 53
                                                                                                       // 54
  var req = {                                                                                          // 55
    host: 'www.google.com',                                                                            // 56
    port: 443,                                                                                         // 57
    path: this._buildPath(params),                                                                     // 58
    method: 'GET',                                                                                     // 59
    headers: {                                                                                         // 60
      'Authorization': 'OAuth ' + this.token                                                           // 61
    }                                                                                                  // 62
  };                                                                                                   // 63
                                                                                                       // 64
  // console.log(req);                                                                                 // 65
                                                                                                       // 66
  https.request(req, function (res) {                                                                  // 67
    var data = '';                                                                                     // 68
                                                                                                       // 69
    res.on('end', function () {                                                                        // 70
      if (res.statusCode < 200 || res.statusCode >= 300) {                                             // 71
        var error = new Error('Bad client request status: ' + res.statusCode);                         // 72
        return cb(error);                                                                              // 73
      }                                                                                                // 74
      try {                                                                                            // 75
        data = JSON.parse(data);                                                                       // 76
        cb(null, data);                                                                                // 77
      }                                                                                                // 78
      catch (err) {                                                                                    // 79
        cb(err);                                                                                       // 80
      }                                                                                                // 81
    });                                                                                                // 82
                                                                                                       // 83
    res.on('data', function (chunk) {                                                                  // 84
      //console.log(chunk.toString());                                                                 // 85
      data += chunk;                                                                                   // 86
    });                                                                                                // 87
                                                                                                       // 88
    res.on('error', function (err) {                                                                   // 89
      cb(err);                                                                                         // 90
    });                                                                                                // 91
                                                                                                       // 92
    //res.on('close', onFinish);                                                                       // 93
  }).on('error', function (err) {                                                                      // 94
    cb(err);                                                                                           // 95
  }).end();                                                                                            // 96
};                                                                                                     // 97
                                                                                                       // 98
GoogleContacts.prototype._getPhotoData = function (params, cb) {                                       // 99
  var self = this;                                                                                     // 100
                                                                                                       // 101
  if (typeof params === 'function') {                                                                  // 102
    cb = params;                                                                                       // 103
    params = {};                                                                                       // 104
  }                                                                                                    // 105
                                                                                                       // 106
  var req = {                                                                                          // 107
    host: 'www.google.com',                                                                            // 108
    port: 443,                                                                                         // 109
    path: this._buildPath(params),                                                                     // 110
    method: 'GET',                                                                                     // 111
    headers: {                                                                                         // 112
      'Authorization': 'OAuth ' + this.token                                                           // 113
    }                                                                                                  // 114
  };                                                                                                   // 115
                                                                                                       // 116
  // console.log(req);                                                                                 // 117
                                                                                                       // 118
  https.request(req, function (res) {                                                                  // 119
    var data;                                                                                          // 120
    var dataType = false;                                                                              // 121
    // var data = new Buffer();                                                                        // 122
                                                                                                       // 123
    res.on('end', function () {                                                                        // 124
      if (res.statusCode < 200 || res.statusCode >= 300) {                                             // 125
        var error = new Error('Bad client request status: ' + res.statusCode);                         // 126
        return cb(error);                                                                              // 127
      }                                                                                                // 128
      try {                                                                                            // 129
        // console.log('end: ', data.length);                                                          // 130
        cb(null, data);                                                                                // 131
      }                                                                                                // 132
      catch (err) {                                                                                    // 133
        cb(err);                                                                                       // 134
      }                                                                                                // 135
    });                                                                                                // 136
                                                                                                       // 137
    res.on('data', function (chunk) {                                                                  // 138
      // console.log(req.path, " : ", chunk.toString().length, ": ", chunk.length);                    // 139
      if (dataType) {                                                                                  // 140
        chunk_buffer = new Buffer(chunk, 'binary');                                                    // 141
        // data += chunk;                                                                              // 142
        data = Buffer.concat([data, chunk_buffer]);                                                    // 143
      } else {                                                                                         // 144
        data = new Buffer(chunk, 'binary');                                                            // 145
        dataType = true;                                                                               // 146
        // console.log('start: ');                                                                     // 147
      }                                                                                                // 148
      // console.log('chunk: ', chunk.length);                                                         // 149
    });                                                                                                // 150
                                                                                                       // 151
    res.on('error', function (err) {                                                                   // 152
      cb(err);                                                                                         // 153
    });                                                                                                // 154
                                                                                                       // 155
    //res.on('close', onFinish);                                                                       // 156
  }).on('error', function (err) {                                                                      // 157
    cb(err);                                                                                           // 158
  }).end();                                                                                            // 159
};                                                                                                     // 160
                                                                                                       // 161
GoogleContacts.prototype.getPhoto = function (path, cb) {                                              // 162
  var self = this;                                                                                     // 163
                                                                                                       // 164
  this._getPhotoData({path: path}, receivedPhotoData);                                                 // 165
  function receivedPhotoData(err, data) {                                                              // 166
    cb(err, data);                                                                                     // 167
  }                                                                                                    // 168
};                                                                                                     // 169
                                                                                                       // 170
GoogleContacts.prototype.getContacts = function (cb, contacts) {                                       // 171
  var self = this;                                                                                     // 172
                                                                                                       // 173
  this._get({ type: 'contacts' }, receivedContacts);                                                   // 174
  function receivedContacts(err, data) {                                                               // 175
    if (err) return cb(err);                                                                           // 176
                                                                                                       // 177
    self._saveContactsFromFeed(data.feed);                                                             // 178
                                                                                                       // 179
    var next = false;                                                                                  // 180
    data.feed.link.forEach(function (link) {                                                           // 181
      if (link.rel === 'next') {                                                                       // 182
        next = true;                                                                                   // 183
        var path = url.parse(link.href).path;                                                          // 184
        self._get({ path: path }, receivedContacts);                                                   // 185
      }                                                                                                // 186
    });                                                                                                // 187
    if (!next) {                                                                                       // 188
      cb(null, self.contacts);                                                                         // 189
    }                                                                                                  // 190
  }                                                                                                    // 191
};                                                                                                     // 192
                                                                                                       // 193
GoogleContacts.prototype._saveContactsFromFeed = function (feed) {                                     // 194
  var self = this;                                                                                     // 195
  //console.log(feed);                                                                                 // 196
  var i = 0;                                                                                           // 197
  feed.entry.forEach(function (entry) {                                                                // 198
    try {                                                                                              // 199
      var name = entry.title['$t'];                                                                    // 200
      var email = entry['gd$email'][0].address; // only save first email                               // 201
      var photoUrl;                                                                                    // 202
      var mimeType;                                                                                    // 203
      entry.link.some(function(link) {                                                                 // 204
        if ((link.rel) && (link.rel.indexOf('#photo') !== -1) && (link.type.indexOf('image') !== -1)){ // 205
          photoUrl = link.href;                                                                        // 206
          mimeType = link.type;                                                                        // 207
          // console.log(link);                                                                        // 208
        }                                                                                              // 209
      });                                                                                              // 210
      if (photoUrl){                                                                                   // 211
        self.contacts.push({ name: name, email: email, photoUrl: photoUrl, mime_type: mimeType});      // 212
      }                                                                                                // 213
    }                                                                                                  // 214
    catch (e) {                                                                                        // 215
      // property not available...                                                                     // 216
    }                                                                                                  // 217
  });                                                                                                  // 218
  // console.log(self.contacts);                                                                       // 219
  console.log(self.contacts.length);                                                                   // 220
};                                                                                                     // 221
                                                                                                       // 222
GoogleContacts.prototype._buildPath = function (params) {                                              // 223
  if (params.path) return params.path;                                                                 // 224
                                                                                                       // 225
  params = params || {};                                                                               // 226
  params.type = params.type || 'contacts';                                                             // 227
  params.alt = params.alt || 'json';                                                                   // 228
  params.projection = params.projection || 'thin';                                                     // 229
  params.email = params.email || 'default';                                                            // 230
  params['max-results'] = params['max-results'] || 2000;                                               // 231
                                                                                                       // 232
  var query = {                                                                                        // 233
    alt: params.alt,                                                                                   // 234
    'max-results': params['max-results']                                                               // 235
  };                                                                                                   // 236
                                                                                                       // 237
  var path = '/m8/feeds/';                                                                             // 238
  path += params.type + '/';                                                                           // 239
  path += params.email + '/';                                                                          // 240
  path += params.projection;                                                                           // 241
  path += '?' + qs.stringify(query);                                                                   // 242
                                                                                                       // 243
  return path;                                                                                         // 244
};                                                                                                     // 245
                                                                                                       // 246
GoogleContacts.prototype.refreshAccessToken = function (refreshToken, cb) {                            // 247
  if (typeof params === 'function') {                                                                  // 248
    cb = params;                                                                                       // 249
    params = {};                                                                                       // 250
  }                                                                                                    // 251
                                                                                                       // 252
  var data = {                                                                                         // 253
    refresh_token: refreshToken,                                                                       // 254
    client_id: this.consumerKey,                                                                       // 255
    client_secret: this.consumerSecret,                                                                // 256
    grant_type: 'refresh_token'                                                                        // 257
                                                                                                       // 258
  };                                                                                                   // 259
                                                                                                       // 260
  var body = qs.stringify(data);                                                                       // 261
                                                                                                       // 262
  var opts = {                                                                                         // 263
    host: 'accounts.google.com',                                                                       // 264
    port: 443,                                                                                         // 265
    path: '/o/oauth2/token',                                                                           // 266
    method: 'POST',                                                                                    // 267
    headers: {                                                                                         // 268
      'Content-Type': 'application/x-www-form-urlencoded',                                             // 269
      'Content-Length': body.length                                                                    // 270
    }                                                                                                  // 271
  };                                                                                                   // 272
                                                                                                       // 273
  //console.log(opts);                                                                                 // 274
  //console.log(data);                                                                                 // 275
                                                                                                       // 276
  var req = https.request(opts, function (res) {                                                       // 277
    var data = '';                                                                                     // 278
    res.on('end', function () {                                                                        // 279
      if (res.statusCode < 200 || res.statusCode >= 300) {                                             // 280
        var error = new Error('Bad client request status: ' + res.statusCode);                         // 281
        return cb(error);                                                                              // 282
      }                                                                                                // 283
      try {                                                                                            // 284
        data = JSON.parse(data);                                                                       // 285
        //console.log(data);                                                                           // 286
        cb(null, data.access_token);                                                                   // 287
      }                                                                                                // 288
      catch (err) {                                                                                    // 289
        cb(err);                                                                                       // 290
      }                                                                                                // 291
    });                                                                                                // 292
                                                                                                       // 293
    res.on('data', function (chunk) {                                                                  // 294
      //console.log(chunk.toString());                                                                 // 295
      data += chunk;                                                                                   // 296
    });                                                                                                // 297
                                                                                                       // 298
    res.on('error', function (err) {                                                                   // 299
      cb(err);                                                                                         // 300
    });                                                                                                // 301
                                                                                                       // 302
    //res.on('close', onFinish);                                                                       // 303
  }).on('error', function (err) {                                                                      // 304
    cb(err);                                                                                           // 305
  });                                                                                                  // 306
                                                                                                       // 307
  req.write(body);                                                                                     // 308
  req.end();                                                                                           // 309
};                                                                                                     // 310
/////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['long:google-contacts'] = {
  GoogleContacts: GoogleContacts
};

})();

//# sourceMappingURL=long_google-contacts.js.map
