(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['sashko:katex'] = {};

})();

//# sourceMappingURL=sashko_katex.js.map
