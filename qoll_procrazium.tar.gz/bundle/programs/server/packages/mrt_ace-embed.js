(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['mrt:ace-embed'] = {};

})();

//# sourceMappingURL=mrt_ace-embed.js.map
