(function(){var filename='server/config/ConfigTwitter.js';

/**Accounts.loginServiceConfiguration.remove({"service": "twitter"});
Accounts.loginServiceConfiguration.insert({
 "service": "twitter",
 "consumerKey" : "<yours>",
 "secret" : "<yours>"
});
Twitter: consumerKey, secret
**/


//http://meteor.hromnik.com

})();
