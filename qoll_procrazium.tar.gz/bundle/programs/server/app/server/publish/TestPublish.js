(function(){
var Browsers = [
	{engine : 'Falaanaa', browser : 'Internet Explorer', platform : 'Windows', version : '11.0', grade : '1.0'},
	{engine : 'Dhimaakaa', browser : 'Firefox', platform : 'Linux', version : '17.1', grade : '2.0'},
	{engine : 'Imkaa', browser : 'Chrome', platform : 'Solaris', version : '23.4', grade : '3.0'},
	{engine : 'Thumka', browser : 'Netscape', platform : 'IOS', version : '1.0', grade : '4.0'}
];

//DataTable.debug = "true";
//DataTable.publish("all_browsers", Browsers);

/**RowsTable = new DataTableComponent
  subscription: "rows"
  collection: Rows
  query:
    someProperty: "someValue"
    otherProperty: $regex: "value"
    nested:
      property: $gte: 0

  RowsTable.debug = "true";
  RowsTable.publish("all_browsers", Browsers);**/

})();
