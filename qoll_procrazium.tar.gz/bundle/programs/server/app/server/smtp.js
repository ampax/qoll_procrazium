(function(){Meteor.startup(function () {
//process.env.MAIL_URL = 'smtp://kaushik.amit:gwtw35.ap@smtp.sendgrid.net:587';
});

})();
