(function(){var filename = 'server/db/QollTypeCustomDb.js';

QollTypeCustom = new Meteor.Collection('QOLL_TYPE_CUSTOM');

})();
